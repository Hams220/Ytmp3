/* =========================================================
 * Bot WhatsApp – Auto Hydro Response
 * =========================================================*/
const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  delay
} = require("@whiskeysockets/baileys");
const qrcode = require("qrcode-terminal");
const fs   = require("fs");
const path = require("path");
const moment = require("moment-timezone");
moment.tz.setDefault("Asia/Jakarta");

/* ---------- Konfigurasi ---------- */
const CONFIG_PATH   = "./config.json";
const KODE_PATH     = "./kode_unik.json";
const MEDIA_DIR     = "./media";
const AUTH_DIR      = "./auth";
//const TARGET_JID    = "120363164235959904@g.us";
const TARGET_JID = "120363164235959904@g";
const OWNER_JID     = "6285798537328@s.whatsapp.net";

/* ---------- Variabel Global ---------- */
let sock;
let qrShown = false;

/* ---------- Helper: baca JSON dengan aman ---------- */
function loadJson(file, fallback = []) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, "utf-8"));
  } catch (e) {
    console.error(`[ERROR] gagal baca ${file}:`, e.message);
    return fallback;
  }
}

/* ---------- Helper: simpan JSON ---------- */
function saveJson(file, data) {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error(`[ERROR] gagal tulis ${file}:`, e.message);
  }
}

/* ---------- Inisialisasi ---------- */
async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  sock = makeWASocket({
    auth: state,
    printQRInTerminal: false
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
    if (qr && !qrShown) {
      qrShown = true;
      console.log("Scan QR di bawah ini:");
      qrcode.generate(qr, { small: true });
    }

    if (connection === "close") {
      const reason = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = reason !== DisconnectReason.loggedOut;
      console.log("Koneksi tertutup. Reconnect =", shouldReconnect);
      if (shouldReconnect) startBot();
    } else if (connection === "open") {
      console.log("Bot WhatsApp sudah terhubung ✅");
    }
  });

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg || msg.key.fromMe) return;
    const from  = msg.key.remoteJid;
    const body  = msg.message?.conversation?.trim() ||
                  msg.message?.extendedTextMessage?.text?.trim() ||
                  "";

    if (!body) return;

    console.log(`[${from}] ${body}`);

    /* ---------- Command ---------- */
    if (body.startsWith("!")) {
      const cfg = loadJson(CONFIG_PATH, { commands: {} });
      const cmd = body.split(" ")[0].slice(1).toLowerCase();

      if (!cfg.commands[cmd]) {
        await sock.sendMessage(from, {
          text: "❌ Command tidak ditemukan, ketik *!menu* untuk melihat command list."
        });
        return;
      }

      try {
        require("./cmdHandler")(sock, from, body, OWNER_JID, msg);
      } catch (e) {
        console.error("cmdHandler gagal:", e);
        await sock.sendMessage(from, { text: "❌ Terjadi kesalahan saat menjalankan command." });
      }
      return; 
    }

    /* ---------- Auto-Response Hydro ---------- */
    const kodeData = loadJson(KODE_PATH, []);

    /* 1. Hydro ON */
    if (body.includes("Yuk ikuti Promo *HYDROPLUS Nonstop Miliaran !*") || body.includes("Selamat ya, kamu sudah dapat semua hadiahmu dari Hydroplus.")) {
      const tanggal = moment().format("ddd, DD MMM YYYY");
      const jam = moment().format("HH:mm");
      const pesan = `INFO PENTING HYDRO ON!! ⚡
╭──❍「 *HYDRO INFO* 」❍
├ Status : ON
├ Tanggal : ${tanggal}
├ Jam    : ${jam}
├ tagall : OFF
╰───────────────❍`;

      try {
        await sock.sendMessage(TARGET_JID, {text: pesan}, {
          quoted: {
            key: {
              remoteJid: 'status@broadcast',
              fromMe: false,
              id: '',
              participant: '0@s.whatsapp.net'
            }, message: {
              conversation: 'HydroInfo@HamsterBot'
            }
            }
        });
        await sock.sendMessage(OWNER_JID, { text: "*HYDRO ON*" });
      } catch (e) {
        console.error("Gagal kirim pesan hydro-on:", e);
      }
    }

    /* 2. Minta kode unik */
    if (body.includes("Silakan tuliskan kode unik")) {
      const idx = kodeData.findIndex(k => k.status === "Elig");
      if (idx !== -1) {
        const kode = kodeData[idx].kode;
        await sock.sendMessage(from, { text: kode });
        kodeData[idx].status = "Pending";
        saveJson(KODE_PATH, kodeData);
      } else {
        await sock.sendMessage(OWNER_JID, { text: "Bang, kodenya abis. Hydro udah on 🔥" });
      }
    }

    /* 3. Minta foto botol */
    if (body.includes("Mohon kirimkan bukti foto kode unik")) {
      const file = path.join(MEDIA_DIR, "botol.jpg");
      if (fs.existsSync(file)) {
        await sock.sendMessage(from, { image: fs.readFileSync(file) });
      } else {
        await sock.sendMessage(from, { text: "Gambar botol tidak tersedia." });
      }
    }

    /* 4. Minta KTP */
    if (body.includes("Untuk verifikasi lebih lanjut mohon kirimkan foto KTP")) {
      const file = path.join(MEDIA_DIR, "ktp.jpg");
      if (fs.existsSync(file)) {
        await sock.sendMessage(from, { image: fs.readFileSync(file) });
      } else {
        await sock.sendMessage(from, { text: "Gambar KTP tidak tersedia." });
      }
    }

    /* 5. Sukses verifikasi */
    if (body.includes("Terima kasih, KTP dan kode unik kamu berhasil diproses")) {
      const idx = kodeData.findIndex(k => k.status === "Pending");
      if (idx !== -1) {
        kodeData[idx].status = "Used";
        saveJson(KODE_PATH, kodeData);
      }
    }

    /* 6. Trigger ucapan terima kasih */
    if (body.includes("Terima kasih telah berpartisipasi")) {
      await delay(60000);
      await sock.sendMessage(from, { text: "Hi" });
    }
  });
}

/* ---------- Jalankan ---------- */
startBot().catch(console.error);

