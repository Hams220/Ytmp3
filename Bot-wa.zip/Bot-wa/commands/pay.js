const fs = require('fs');
const path = require('path');
const { text } = require('stream/consumers');
const MEDIA_DIR     = "./media";
module.exports = async (sock, from, pr, query, OWNER_JID, msg) => {

      try {
        const harga = 5000;
        const metode = [
          '*1. QRIS (semua e-wallet & bank)*',
          '*2. Dana: 0838-4977-3139*',
          '*3. OVO: 0838-4977-3139*',
          '*4. GOPAY: 0838-4977-3139*',
          '*5. Transfer Bank: BCA / BRI / Mandiri*'
        ];

        const list = metode.join('\n');

        const teks = `🧾 Berikut adalah metode pembayaran HAMS

${list}

💳 *Nominal pembayaran: Rp ${harga.toLocaleString('id-ID')}*

Setelah melakukan pembayaran, kirim bukti transfer atau ketik \`!konfirmasi\` ya.`;

        // Ambil gambar QRIS
        const file = path.join(MEDIA_DIR, "ktp.jpg");

        // Kirim gambar + caption
        await sock.sendMessage(from, {
          image: fs.readFileSync(file),
          caption: teks,
        });

      } catch (err) {
        console.error(err);
        return sock.sendMessage(from, { text: '❌ Gagal memproses permintaan pembayaran.' });
      }
    }
