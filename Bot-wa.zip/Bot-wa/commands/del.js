// commands/del.js
const fs   = require('fs');
const path = require('path');
const cfgPath = path.join(__dirname, '..', 'config.json');
const kodePath = path.join(__dirname, '..', 'kode_unik.json');

module.exports = async (sock, from, pr, query, OWNER_JID, msg) => {
  const isAdmin = from === OWNER_JID;
  if (!isAdmin) {await sock.sendMessage(from, { 
  text: 'Command ini khusus admin' }, {quoted: msg}); return;}


  if (!query) return sock.sendMessage(from, { text: '❌ Query tidak boleh kosong.' });

  switch (pr) {
    case 'kode':
      try {
        let data = fs.existsSync(kodePath) ? JSON.parse(fs.readFileSync(kodePath)) : [];
        const idx = data.findIndex(k => k.kode === query);
        if (idx === -1) return sock.sendMessage(from, { text: `❌ Kode *${query}* tidak ditemukan.` });
        data.splice(idx, 1);
        fs.writeFileSync(kodePath, JSON.stringify(data, null, 2));
        return sock.sendMessage(from, { text: `✅ Kode *${query}* berhasil dihapus.` });
      } catch {
        return sock.sendMessage(from, { text: '❌ Gagal memproses kode_unik.json' });
      }

    case 'command':
      const cfg = require(cfgPath);
      const key = query.startsWith('!') ? query.slice(1) : query;
      if (!cfg.commands[key]) return sock.sendMessage(from, { text: `❌ Command *${query}* tidak ditemukan.` });
      delete cfg.commands[key];
      fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2));
      return sock.sendMessage(from, { text: `✅ Command *${query}* berhasil dihapus.` });

    case 'perintah':
      const cfg2 = require(cfgPath);
      const pIdx = cfg2.perintah.indexOf(query);
      if (pIdx === -1) return sock.sendMessage(from, { text: `❌ Perintah *${query}* tidak ditemukan.` });
      cfg2.perintah.splice(pIdx, 1);
      fs.writeFileSync(cfgPath, JSON.stringify(cfg2, null, 2));
      return sock.sendMessage(from, { text: `✅ Perintah *${query}* berhasil dihapus.` });

    default:
      return sock.sendMessage(from, { text: '❌ Perintah tidak valid.' });
  }
};

