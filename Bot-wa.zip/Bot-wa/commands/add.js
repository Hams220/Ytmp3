// commands/add.js
const fs   = require('fs');
const path = require('path');
const kodePath = path.join(__dirname, '..', 'kode_unik.json');
const cfg   = require('../config.json');
const dagetPath = path.join(__dirname, '..', 'dana_kaget.json');

module.exports = async (sock, from, pr, query, OWNER_JID, msg) => {
  const isAdmin = from === OWNER_JID;
  if (!isAdmin) {await sock.sendMessage(from, { 
  text: 'Command ini khusus admin' }, {quoted: msg}); return;}

  if (!query) return await sock.sendMessage(from, { text: '❌ Query tidak boleh kosong.' });

  switch (pr) {
    case 'kode':
      try {
        const data = fs.existsSync(kodePath)
          ? JSON.parse(fs.readFileSync(kodePath))
          : [];
        data.push({ kode: query, status: 'Elig' });
        fs.writeFileSync(kodePath, JSON.stringify(data, null, 2));
        return sock.sendMessage(from, { text: `✅ Kode *${query}* berhasil ditambahkan.` });
      } catch {
        return sock.sendMessage(from, { text: '❌ Gagal menulis kode_unik.json' });
      }

    case 'command':
      if (cfg.commands[query.slice(1)]) {
        return sock.sendMessage(from, { text: '❌ Command sudah ada.' });
      }
      cfg.commands[query.slice(1)] = { desc: 'Custom command', args: [] };
      fs.writeFileSync(path.join(__dirname, '..', 'config.json'), JSON.stringify(cfg, null, 2));
      return sock.sendMessage(from, { text: `✅ Command *${query}* berhasil ditambahkan.` });

    case 'perintah':
      if (cfg.perintah.includes(query)) {
        return sock.sendMessage(from, { text: '❌ Perintah sudah ada.' });
      }
      cfg.perintah.push(query);
      fs.writeFileSync(path.join(__dirname, '..', 'config.json'), JSON.stringify(cfg, null, 2));
      return sock.sendMessage(from, { text: `✅ Perintah *${query}* berhasil ditambahkan.` });

    case 'danakaget':
      try {
        const data = fs.existsSync(dagetPath)
          ? JSON.parse(fs.readFileSync(dagetPath))
          : [];

        data.push({
          link: query,
          status: 'elig',
          slot: 5
        });

        fs.writeFileSync(dagetPath, JSON.stringify(data, null, 2));
        return sock.sendMessage(from, { text: `✅ Link berhasil ditambahkan dengan slot *5* dan status *elig*.` });
      } catch {
        return sock.sendMessage(from, { text: '❌ Gagal menyimpan data link ke dagetPath' });
      }

    default:
      return sock.sendMessage(from, { text: '❌ Perintah tidak valid.' });
  }
};

