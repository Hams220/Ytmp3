const fs = require('fs');
const path = require('path');
const kodePath = path.join(__dirname, '..', 'kode_unik.json');
const dagetPath = path.join(__dirname, '..', 'dana_kaget.json');

const head = '╭──❍「 ';
const body = '├ ';
const foot = '╰─────────────';

module.exports = async (sock, from, pr, query,OWNER_JID, msg) => {
  switch (pr) {
    case 'kode':
      try {
        const data = JSON.parse(fs.readFileSync(kodePath));
        const list = data.map(k => `${body}${k.kode} - ${k.status}`).join('\n');
        return await sock.sendMessage(from, { text: `${head}*Kode Unik* 」❍\n${list}\n${foot}` }, {quoted: msg});
      } catch {
        return await sock.sendMessage(from, { text: '❌ Gagal membaca kode_unik.json' }, {quoted: msg});
      }

    case 'command':
    case 'perintah':
      const { commands, perintah: listPr } = require('../config.json');
      const list = pr === 'command'
        ? Object.keys(commands).map(c => `${body}!${c}`).join('\n')
        : listPr.map(p => `${body}${p}`).join('\n');
      const title = pr === 'command' ? 'Daftar Command' : 'Perintah Tersedia';
      return sock.sendMessage(from, { text: `${head}*${title}* 」❍\n${list}\n${foot}` });

    case 'danakaget':
      const data = JSON.parse(fs.readFileSync(dagetPath));
      const eligData = data
        .map((item, index) => ({ ...item, index })) // inject index asli ke setiap item
        .filter(k => k.status === 'elig' && k.slot > 0);

      if (eligData.length === 0) {
        return await sock.sendMessage(from, { text: '⚠️ Gak ada link dengan status *elig*.' }, { quoted: msg });
      }

      const random = eligData[Math.floor(Math.random() * eligData.length)];
      const link = random.link;
      const targetIndex = random.index; // ini udah index asli

      data[targetIndex].slot -= 1;
      if (data[targetIndex].slot <= 0) {
        data[targetIndex].status = 'done';
      }

      fs.writeFileSync(dagetPath, JSON.stringify(data, null, 2));

      const isiPesan = `Selamat kamu dapat dana kaget dari Hams\n${head}*Dana kaget* 」❍\n${body}${link} - ${data[targetIndex].status}\n${foot}`;
      return await sock.sendMessage(from, { text: isiPesan }, { quoted: msg });
          }
};

