const fs = require('fs');
const path = require('path');
const axios = require('axios');
const kodePath = path.join(__dirname, '..', 'kode_unik.json');

module.exports = async (sock, from, pr, query, OWNER_JID, msg) => {
  const nomor = query.replace(/^@/, '');
  const TargetJid = nomor + '@s.whatsapp.net';

  switch (pr) {
    case 'kode':
      try {
        const data = fs.existsSync(kodePath) ? JSON.parse(fs.readFileSync(kodePath)) : [];
        const eligData = data.filter(k => k.status.toLowerCase() === 'elig');

        if (eligData.length === 0) {
          return sock.sendMessage(from, { text: '❌ Gak ada kode dengan status *elig*.' });
        }

        const k = eligData[0];
        const harga = 5000;
        const teks = `Berikut adalah kode unik dari HAMS

*├ ${k.kode} - ${k.status}*
*├ Harga Rp ${harga.toLocaleString('id-ID')}*

Untuk melakukan pembayaran ketik \`!pay\`

Atau klik link https://wa.me/6283849773139?text=!pay`;

        // Ambil thumbnail dari link (gunakan favicon WhatsApp atau gambar custom lo)
        const thumbUrl = 'https://hawilpay.my.id/img/HamsBot.jpg';
        const res = await axios.get(thumbUrl, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(res.data, 'binary');

        // Kirim ke target
        await sock.sendMessage(TargetJid, {
          image: buffer,
          caption: teks,
        });

        // Ubah status jadi pending
        const idx = data.findIndex(d => d.kode === k.kode);
        data[idx].status = 'pending';
        fs.writeFileSync(kodePath, JSON.stringify(data, null, 2));

        // Optional: kasih notifikasi juga ke pengirim
        await sock.sendMessage(from, {
          text: `✅ Kode berhasil dikirim ke @${nomor}`,
          mentions: [TargetJid]
        });
      } catch (err) {
        console.error(err);
        return sock.sendMessage(from, { text: '❌ Terjadi error saat memproses kode elig.' });
      }
      break;
  }
};
