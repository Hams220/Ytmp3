delete require.cache[require.resolve('../config.json')];
const fs   = require('fs');
const path = require('path');

const cfgPath  = path.join(__dirname, '..', 'config.json');
const kodePath = path.join(__dirname, '..', 'kode_unik.json');

const head = '╭──❍「 ';
const foot = '╰─────────────';

module.exports = async (sock, from, pr, query, OWNER_JID, msg) => {
  const isAdmin = from === OWNER_JID;
  if (!isAdmin) {await sock.sendMessage(from, { 
  text: 'Command ini khusus admin' }, {quoted: msg}); return;}

const [lama, ...baruArr] = query.split(' ');
  const baru = baruArr.join(' ');

  if (!lama || !baru) {
    return sock.sendMessage(from, { text: '❌ Format: !set <perintah> <lama> <baru>' });
  }
  switch (pr) {
    /* 1. Ubah kode di kode_unik.json */
    case 'kode':
      try {
        let data = fs.existsSync(kodePath) ? JSON.parse(fs.readFileSync(kodePath)) : [];
        const idx = data.findIndex(k => k.kode === lama);
        if (idx === -1) return sock.sendMessage(from, { text: `❌ Kode *${lama}* tidak ditemukan.` });
        data[idx].kode = baru;
        fs.writeFileSync(kodePath, JSON.stringify(data, null, 2));
        return sock.sendMessage(from, { text: `✅ Kode *${lama}* → *${baru}* berhasil diubah.` });
      } catch {
        return sock.sendMessage(from, { text: '❌ Gagal memproses kode_unik.json' });
      }

    /* 2. Ubah nama command di config.json */
    case 'command':
      const cfgC = require(cfgPath);
      const keyLama = lama.startsWith('!') ? lama.slice(1) : lama;
      const keyBaru = baru.startsWith('!') ? baru.slice(1) : baru;

      if (!cfgC.commands[keyLama]) {
        return sock.sendMessage(from, { text: `❌ Command *${lama}* tidak ditemukan.` });
      }
      cfgC.commands[keyBaru] = { ...cfgC.commands[keyLama] };
      delete cfgC.commands[keyLama];
      fs.writeFileSync(cfgPath, JSON.stringify(cfgC, null, 2));
      return sock.sendMessage(from, { text: `✅ Command *${lama}* → *${baru}* berhasil diubah.` });

    /* 3. Ubah nama perintah di config.json */
    case 'perintah':
      const cfgP = require(cfgPath);
      const pIdx = cfgP.perintah.indexOf(lama);
      if (pIdx === -1) {
        return sock.sendMessage(from, { text: `❌ Perintah *${lama}* tidak ditemukan.` });
      }
      cfgP.perintah[pIdx] = baru;
      fs.writeFileSync(cfgPath, JSON.stringify(cfgP, null, 2));
      return sock.sendMessage(from, { text: `✅ Perintah *${lama}* → *${baru}* berhasil diubah.` });

      case 'statusKode':
      try {
        let data = fs.existsSync(kodePath) ? JSON.parse(fs.readFileSync(kodePath)) : [];
        const idx = data.findIndex(k => k.kode === lama);
        if (idx === -1) return sock.sendMessage(from, { text: `❌ Kode *${lama}* tidak ditemukan.` });
        data[idx].status = baru;
        fs.writeFileSync(kodePath, JSON.stringify(data, null, 2));
        return sock.sendMessage(from, { text: `✅ Status kode *${lama}* → *${baru}* berhasil diubah.` });
      } catch {
        return sock.sendMessage(from, { text: '❌ Gagal memproses kode_unik.json' });
      }

    default:
      return sock.sendMessage(from, { text: '❌ Perintah tidak valid. Gunakan kode|command|perintah.' });
  }
};

