const fs = require('fs');
const path = require('path');
const { commands, perintah } = require('./config.json');
const buildMenu = require('./lib/menuBuilder');

const kodePath = path.join(__dirname, 'kode_unik.json');

module.exports = async (sock, from, txt, OWNER_JID, msg) => {
  const [cmdRaw, pr, ...rest] = txt.split(' ');
  const query = rest.join(' ');
  const cmd = cmdRaw.slice(1); // hapus prefix

  // Menu otomatis
  if (cmd === 'menu') {
    return sock.sendMessage(from, { text: buildMenu() });
  }

  // Validasi command
  if (!commands[cmd]) return;

  // Validasi perintah untuk command tertentu
  const requiredArgs = commands[cmd].args;
  if (requiredArgs.includes('perintah') && !perintah.includes(pr)) {
    return sock.sendMessage(from, {
      text: `❌ Perintah tidak dikenal.\nGunakan: ${perintah.join(', ')}`
    });
  }

  // Dynamic import command handler
  try {
    const handlerPath = path.join(__dirname, 'commands', `${cmd}.js`);
    if (!fs.existsSync(handlerPath)) {
      return sock.sendMessage(from, { text: '❌ Command belum diimplementasikan.' });
    }

    const handler = require(handlerPath);
    await handler(sock, from, pr, query, OWNER_JID, msg);
  } catch (e) {
    console.error(e);
    sock.sendMessage(from, { text: '❌ Terjadi kesalahan saat menjalankan command.' });
  }
};

